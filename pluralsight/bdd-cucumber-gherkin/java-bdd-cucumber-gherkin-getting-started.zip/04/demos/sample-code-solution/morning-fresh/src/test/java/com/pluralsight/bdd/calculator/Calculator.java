package com.pluralsight.bdd.calculator;

public class Calculator {
    public Integer add(Integer a, Integer b) {
        return a + b;
    }
}
