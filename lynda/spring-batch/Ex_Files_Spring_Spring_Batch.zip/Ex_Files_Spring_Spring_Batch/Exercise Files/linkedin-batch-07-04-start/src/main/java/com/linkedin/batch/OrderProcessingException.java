package com.linkedin.batch;

public class OrderProcessingException extends Exception {

}
